package mvc;

public interface Subscriber {
    void update(String message);
}
