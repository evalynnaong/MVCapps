package midterm;

public interface Strategy {
    boolean choose();
}
