package midterm;

public class AlwaysCooperate implements Strategy{

    public boolean choose() {
        return true;
    }
}
