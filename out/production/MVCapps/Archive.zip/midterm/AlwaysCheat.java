package midterm;

public class AlwaysCheat implements Strategy{

    public boolean choose() {
        return false;
    }
}
